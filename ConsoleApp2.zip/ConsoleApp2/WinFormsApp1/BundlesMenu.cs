﻿using Steam.Core;
using Steam.Data.Models;
using Steam.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;

namespace WinFormsApp1
{
    public partial class BundlesMenu : Form
    {
        private readonly SteamDbContext _context;
        private readonly Queries _queries;
        public BundlesMenu()
        {
            _context = new SteamDbContext();
            _queries = new Queries(_context);
            InitializeComponent();
            label1.Hide();
            label2.Hide();
            label3.Hide();
            label4.Hide();
            textBoxBundleId.Hide();
            textBoxBundleName.Hide();
            textBoxBundlePrice.Hide();
            textBoxGameIds.Hide();
            button6.Hide();
            button5.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string filePath = "bundles.txt";
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Файлът bundles.txt не е намерен!");
                    return;
                }

                var lines = File.ReadAllLines(filePath);

                using (var db = new SteamDbContext())
                {
                    var controller = new BundlesController(db);

                    foreach (var line in lines)
                    {
                        var parts = line.Split(';');
                        if (parts.Length < 3) continue;

                        string bundleName = parts[0].Trim();
                        double price = double.Parse(parts[1].Trim());

                        var gameIds = parts[2].Split(',')
                                              .Select(id => int.Parse(id.Trim()))
                                              .ToList();

                        // Създаваме свързващата таблица GamesBundles
                        var gamesBundles = new List<GamesBundles>();
                        foreach (var gameId in gameIds)
                        {
                            gamesBundles.Add(new GamesBundles
                            {
                                gameId = gameId
                            });
                        }

                        // Викаме контролера
                        controller.AddBundle(bundleName, price, gamesBundles);
                    }
                }

                MessageBox.Show("Бъндълите бяха добавени успешно!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка при добавяне на бъндъли: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Show();
            label2.Show();
            label3.Show();
            label4.Show();
            textBoxBundleId.Show();
            textBoxBundleName.Show();
            textBoxBundlePrice.Show();
            textBoxGameIds.Show();
            button6.Hide();
            button5.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            using (var db = new SteamDbContext())
            {
                var bundles = db.Bundles
                    .Include(b => b.gamesBundles)
                    .ThenInclude(gb => gb.Game)
                    .ToList();

                foreach (var bundle in bundles)
                {
                    string gamesList = string.Join(", ", bundle.gamesBundles.Select(gb => gb.Game.Title));
                    listBox1.Items.Add($"ID: {bundle.BundleId}, Name: {bundle.Name}, Price: {bundle.Price}, Games: [{gamesList}]");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Show();
            label2.Hide();
            label3.Hide();
            label4.Hide();
            textBoxBundleId.Show();
            textBoxBundleName.Hide();
            textBoxBundlePrice.Hide();
            textBoxGameIds.Hide();
            button5.Hide();
            button6.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            try
            {
                if (!int.TryParse(textBoxBundleId.Text, out int bundleId))
                {
                    MessageBox.Show("Моля въведете валидно Bundle ID!");
                    return;
                }

                string newName = textBoxBundleName.Text.Trim();
                if (!double.TryParse(textBoxBundlePrice.Text, out double newPrice))
                {
                    MessageBox.Show("Моля въведете валидна цена!");
                    return;
                }

                var gameIds = textBoxGameIds.Text
                    .Split(',', StringSplitOptions.RemoveEmptyEntries)
                    .Select(id => int.Parse(id.Trim()))
                    .ToList();

                using (var db = new SteamDbContext())
                {
                    var games = db.Games.Where(g => gameIds.Contains(g.GameId)).ToList();
                    var newGames = games.Select(g => new GamesBundles
                    {
                        gameId = g.GameId,
                        bundleId = bundleId
                    }).ToList();

                    var controller = new BundlesController(db);
                    controller.UpdateBundle(bundleId, newName, newPrice, newGames);
                }

                MessageBox.Show("Бъндълът беше обновен успешно!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка при обновяване: " + ex.Message);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(textBoxBundleId.Text, out int bundleId))
                {
                    MessageBox.Show("Моля въведете валидно Bundle ID!");
                    return;
                }

                using (var db = new SteamDbContext())
                {
                    var controller = new BundlesController(db);
                    controller.RemoveBundle(bundleId);
                }

                MessageBox.Show("Бъндълът беше премахнат успешно!");
                textBoxBundleId.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка при премахване: " + ex.Message);
            }
        }
    }
}
