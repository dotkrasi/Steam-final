﻿
namespace WinFormsApp1
{
    partial class BundleStore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonBuyBundle = new Button();
            listBox1 = new ListBox();
            textBoxBundleId = new TextBox();
            label1 = new Label();
            button1 = new Button();
            label5 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // buttonBuyBundle
            // 
            buttonBuyBundle.Location = new Point(143, 211);
            buttonBuyBundle.Name = "buttonBuyBundle";
            buttonBuyBundle.Size = new Size(75, 23);
            buttonBuyBundle.TabIndex = 0;
            buttonBuyBundle.Text = "Buy";
            buttonBuyBundle.UseVisualStyleBackColor = true;
            buttonBuyBundle.Click += buttonBuyBundle_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(300, 107);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(445, 214);
            listBox1.TabIndex = 1;
            // 
            // textBoxBundleId
            // 
            textBoxBundleId.Location = new Point(130, 160);
            textBoxBundleId.Name = "textBoxBundleId";
            textBoxBundleId.Size = new Size(100, 23);
            textBoxBundleId.TabIndex = 2;
            textBoxBundleId.TextChanged += textBox1_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(64, 168);
            label1.Name = "label1";
            label1.Size = new Size(60, 15);
            label1.TabIndex = 3;
            label1.Text = "Bundle Id:";
            // 
            // button1
            // 
            button1.Location = new Point(130, 268);
            button1.Name = "button1";
            button1.Size = new Size(100, 23);
            button1.TabIndex = 4;
            button1.Text = "show bundles";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.Location = new Point(12, 9);
            label5.Name = "label5";
            label5.Size = new Size(103, 32);
            label5.TabIndex = 20;
            label5.Text = "Bundles";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources._6153914;
            pictureBox1.Location = new Point(121, 9);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(46, 45);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 21;
            pictureBox1.TabStop = false;
            // 
            // BundleStore
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(150, 120, 240);
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(label5);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(textBoxBundleId);
            Controls.Add(listBox1);
            Controls.Add(buttonBuyBundle);
            Name = "BundleStore";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }



        #endregion

        private Button button1;
        private ListBox listBox1;
        private TextBox textBox1;
        private Button buttonBuyBundle;
        private TextBox textBoxBundleId;
        private Label label1;
        private Label label5;
        private PictureBox pictureBox1;
    }
}