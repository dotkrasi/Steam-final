﻿using Steam.Core;
using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WinFormsApp1
{
    public partial class MainMenu : Form
    {
        private readonly SteamDbContext _context;
        private readonly Queries _queries;

        public MainMenu()
        {
            InitializeComponent();
            //Session.CurrentUser.Username = label2.Text;
            this.textBox1.Text = Session.CurrentUser.Username;
            this.textBox1.Enabled = false;
            this.textBox2.Text = Session.CurrentUser.Balance.ToString();
            this.textBox2.Enabled = false;
            _context = new SteamDbContext();
            _queries = new Queries(_context);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void UserMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserMenu menu = new UserMenu();

            menu.FormClosed += (s, args) => this.Show();

            this.Hide();
            menu.Show();

        }

        private void GenreMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            GenreMenu menu = new GenreMenu();

            menu.FormClosed += (s, args) => this.Show();

            this.Hide();
            menu.Show();
        }

        private void GameMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            GameMenu menu = new GameMenu();

            menu.FormClosed += (s, args) => this.Show();

            this.Hide();
            menu.Show();
        }

        private void BundleMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            BundlesMenu menu = new BundlesMenu();

            menu.FormClosed += (s, args) => this.Show();

            this.Hide();
            menu.Show();
        }

        private void ReviewMenu_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReviewsMenu menu = new ReviewsMenu();

            menu.FormClosed += (s, args) => this.Show();

            this.Hide();
            menu.Show();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void menuStrip1_Click(object sender, EventArgs e)
        {
        }

        private void libraryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            int userId = Session.CurrentUser.UserId; // текущият user
            Library libraryForm = new Library(userId);
            libraryForm.FormClosed += (s, args) => this.Show();
            libraryForm.Show(); // Отваря формата като модален прозорец


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double amount = double.Parse(textBox3.Text);
                int userId = Session.CurrentUser.UserId;
                _queries.AddBalance(userId, amount);

                var updatedUser = _context.Users.Find(userId);
                Session.CurrentUser = updatedUser;

                textBox2.Text = Session.CurrentUser.Balance.ToString("F2");

                MessageBox.Show($"Added {amount}$ to your balance. New balance: {Session.CurrentUser.Balance}$");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void gamesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            int userId = Session.CurrentUser.UserId;
            GamesInStore gamesInStore = new GamesInStore(userId);
            gamesInStore.FormClosed += (s, args) => this.Show();
            gamesInStore.Show();

        }

        private void toolStripContainer1_TopToolStripPanel_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            int userId = Session.CurrentUser.UserId;
            GamesInStore gamesInStore = new GamesInStore(userId);
            gamesInStore.FormClosed += (s, args) => this.Show();
            gamesInStore.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            int userId = Session.CurrentUser.UserId;
            Library libraryForm = new Library(userId);
            libraryForm.FormClosed += (s, args) => this.Show();
            libraryForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            int userId = Session.CurrentUser.UserId;
            BundleStore bundleStore = new BundleStore(userId);
            bundleStore.FormClosed += (s, args) => this.Show();
            bundleStore.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            /*pictureBox1.Image = Image.FromFile(@"C:\Users\krasi\OneDrive\Работен плот\ConsoleApp2\ConsoleApp2\WinFormsApp1\bin\Debug\net8.0-windows\images\pngtree-outline-user-icon-png-image_5045523.jpg");
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;*/
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            /*pictureBox2.Image = Image.FromFile("\"C:\\Users\\krasi\\OneDrive\\Работен плот\\ConsoleApp2\\ConsoleApp2\\WinFormsApp1\\bin\\Debug\\net8.0-windows\\images\\4-49416_gaming-fill-game-icons-png-transparent-png.jpg\"");
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;*/
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
          /*  pictureBox3.Image = Image.FromFile("\"C:\\Users\\krasi\\OneDrive\\Работен плот\\ConsoleApp2\\ConsoleApp2\\WinFormsApp1\\bin\\Debug\\net8.0-windows\\images\\pngtree-game-control-line-icon-vector-png-image_1904129.jpg\"");
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;*/
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
           /* pictureBox4.Image = Image.FromFile("\"C:\\Users\\krasi\\OneDrive\\Работен плот\\ConsoleApp2\\ConsoleApp2\\WinFormsApp1\\bin\\Debug\\net8.0-windows\\images\\bundles-icon-png-favpng-hK6DPz2QXJVzNaQwu0uA0MPU4.jpg\"");
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;*/
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {/*
            pictureBox5.Image = Image.FromFile("\"C:\\Users\\krasi\\OneDrive\\Работен плот\\ConsoleApp2\\ConsoleApp2\\WinFormsApp1\\bin\\Debug\\net8.0-windows\\images\\88-888239_like-all-our-free-icon-packs-these-savings.jpg\"");
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;*/
        }
    }
}
