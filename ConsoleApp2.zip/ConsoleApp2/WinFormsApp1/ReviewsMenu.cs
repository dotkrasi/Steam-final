﻿using Microsoft.EntityFrameworkCore;
using Steam.Core;
using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class ReviewsMenu : Form
    {
        private ReviewsController _reviewsController;
        public ReviewsMenu()
        {
            
            InitializeComponent();
            var context = new SteamDbContext();
            _reviewsController = new ReviewsController(context);
            label1.Hide();
            label3.Hide();
            label4.Hide();
            Description.Hide();
            txtNewDescription.Hide();
            txtNewRating.Hide();
            txtReviewId.Hide();
            txtNewDate.Hide();
            button5.Hide();
            button6.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                string filePath = "reviews.txt";
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Файлът с ревюта не съществува!");
                    return;
                }

                var lines = File.ReadAllLines(filePath);
                foreach (var line in lines)
                {
                    var parts = line.Split(';');
                    if (parts.Length == 4)
                    {
                        string description = parts[0];
                        int rating = int.Parse(parts[1]);
                        DateTime dateTime = DateTime.Parse(parts[2]);
                        int gameId = int.Parse(parts[3]);


                        _reviewsController.AddReview(description, rating, dateTime, gameId);
                    }
                }

                MessageBox.Show("Ревютата са добавени успешно!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка при добавяне на ревюта: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Show();
            label3.Show();
            label4.Show();
            Description.Show();
            txtNewDescription.Show();
            txtNewRating.Show();
            txtReviewId.Show();
            txtNewDate.Show();
            button5.Show();
            button6.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Show();
            label3.Hide();
            label4.Hide();
            Description.Hide();
            txtNewDescription.Hide();
            txtNewRating.Hide();
            txtReviewId.Show();
            txtNewDate.Hide();
            button5.Hide();
            button6.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                listBox1.Items.Clear();
                using (var db = new SteamDbContext())
                {
                    var genresController = new GenresController(db);
                    var reviews = db.Reviews
                                      .Include(r => r.Games) // зареждаме играта
                                      .ToList();
                    foreach (var review in reviews)
                    {
                        listBox1.Items.Add(
                            $"ReviewID: {review.ReviewId} | Game: {review.Games.Title} | Rating: {review.Rating} | {review.Description} | Date: {review.dateTime}"
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка при показване на ревюта: " + ex.Message);
            }
        }

        private void ReviewsMenu_Load(object sender, EventArgs e)
        {

        }

        private void Description_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                int reviewId = int.Parse(txtReviewId.Text);
                string newDescription = txtNewDescription.Text;
                int newRating = int.Parse(txtNewRating.Text);
                DateTime newDate = DateTime.Parse(txtNewDate.Text);

                _reviewsController.UpdateReview(reviewId, newDescription, newRating, newDate);
                MessageBox.Show("Ревюто е обновено успешно!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка при обновяване на ревю: " + ex.Message);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                int reviewId = int.Parse(txtReviewId.Text);
                _reviewsController.RemoveReview(reviewId);
                MessageBox.Show("Ревюто е изтрито успешно!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка при изтриване на ревю: " + ex.Message);
            }
        }
    }
}


