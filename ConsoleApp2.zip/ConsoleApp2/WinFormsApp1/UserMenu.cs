﻿using Steam.Core;
using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class UserMenu : Form
    {
        private readonly SteamDbContext _context;
        private readonly UsersController user;
        public UserMenu()
        {
            InitializeComponent();
            _context = new SteamDbContext();
            user = new UsersController(_context);
            label1.Hide();
            label2.Hide();
            label3.Hide();
            label4.Hide();
            label5.Hide();
            textBox1.Hide();
            textBox2.Hide();
            textBox3.Hide();
            textBox4.Hide();
            textBox5.Hide();
            button5.Hide();
            button6.Hide();
        }
        private void UserMenu_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (var db = new SteamDbContext())
                {
                    string filePath = "users.txt"; // или "Resources/genres.txt"
                    if (!File.Exists(filePath))
                    {
                        MessageBox.Show("Файлът users.txt не е намерен!");
                        return;
                    }

                    var lines = File.ReadAllLines(filePath);

                    foreach (var line in lines)
                    {
                        var parts = line.Split(';');

                        /*     var user = new Users
                             {
                                 Username = parts[0].Trim(),
                                 Email = parts[1].Trim(),
                                 Password = parts[2].Trim(),
                                 Balance = double.Parse(parts[3].Trim())
                             };
                             db.Users.Add(user);*/
                        user.AddUser(
                            parts[0].Trim(),
                            parts[1].Trim(),
                            parts[2].Trim(),
                            int.Parse(parts[3].Trim())
                            );
                    }

                    db.SaveChanges();
                    MessageBox.Show("User-ите бяха успешно добавени!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Възникна грешка: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Show();
            label2.Show();
            label3.Show();
            label4.Show();
            label5.Show();
            textBox1.Show();
            textBox2.Show();
            textBox3.Show();
            textBox4.Show();
            textBox5.Show();
            button5.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Hide();
            label2.Hide();
            label3.Hide();
            label4.Hide();
            label5.Hide();
            textBox1.Hide();
            textBox2.Hide();
            textBox3.Hide();
            textBox4.Hide();
            textBox5.Hide();
            button5.Hide();
            button6.Hide();
            try
            {
                using (var db = new SteamDbContext())
                {
                    var userController = new UsersController(db);

                    var users = userController.GetAllUsers();

                    listBox1.Items.Clear(); // чистим старите резултати
                    foreach (var user in users)
                    {
                        listBox1.Items.Add(
                            $"ID: {user.UserId}, Username: {user.Username}, Email: {user.Email}, Password: {user.Password}, Balance: {user.Balance}"
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка: " + ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                int userId = int.Parse(textBox1.Text);
                string newName = textBox2.Text;
                string newEmail = textBox3.Text;
                string newPassword = textBox4.Text;
                double newBalance = double.Parse(textBox5.Text);

                using (var db = new SteamDbContext())
                {
                    var userController = new UsersController(db);
                    userController.UpdateUser(userId, newName, newEmail, newPassword, newBalance);
                }

                MessageBox.Show("User updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating user: " + ex.Message);
            }
            label1.Hide();
            label2.Hide();
            label3.Hide();
            label4.Hide();
            label5.Hide();
            textBox1.Hide();
            textBox2.Hide();
            textBox3.Hide();
            textBox4.Hide();
            textBox5.Hide();
            button5.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label2.Hide();
            label3.Hide();
            label4.Hide();
            label5.Hide();
            textBox2.Hide();
            textBox3.Hide();
            textBox4.Hide();
            textBox5.Hide();
            button5.Hide();
            label1.Show();
            textBox1.Show();
            button6.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                int userId = int.Parse(textBox1.Text);

                using (var db = new SteamDbContext())
                {
                    var userController = new UsersController(db);
                    userController.DeleteUser(userId);
                }

                MessageBox.Show("User removed successfully!");

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while removing user: " + ex.Message);
            }
        }
    }
}
