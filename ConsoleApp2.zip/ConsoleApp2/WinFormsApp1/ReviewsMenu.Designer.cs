﻿namespace WinFormsApp1
{
    partial class ReviewsMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            listBox1 = new ListBox();
            txtReviewId = new TextBox();
            txtNewDescription = new TextBox();
            txtNewRating = new TextBox();
            txtNewDate = new TextBox();
            label1 = new Label();
            Description = new Label();
            label3 = new Label();
            label4 = new Label();
            button5 = new Button();
            button6 = new Button();
            label5 = new Label();
            SuspendLayout();
            // 
            // button4
            // 
            button4.Location = new Point(74, 233);
            button4.Margin = new Padding(3, 2, 3, 2);
            button4.Name = "button4";
            button4.Size = new Size(91, 56);
            button4.TabIndex = 7;
            button4.Text = "Read Reviews";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Location = new Point(74, 173);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(91, 56);
            button3.TabIndex = 6;
            button3.Text = "Remove Reviews";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(74, 113);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(91, 56);
            button2.TabIndex = 5;
            button2.Text = "Update Reviews";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(74, 53);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(91, 56);
            button1.TabIndex = 4;
            button1.Text = "Add Reviews";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(266, 30);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(315, 139);
            listBox1.TabIndex = 8;
            // 
            // txtReviewId
            // 
            txtReviewId.Location = new Point(357, 184);
            txtReviewId.Name = "txtReviewId";
            txtReviewId.Size = new Size(100, 23);
            txtReviewId.TabIndex = 9;
            // 
            // txtNewDescription
            // 
            txtNewDescription.Location = new Point(357, 213);
            txtNewDescription.Name = "txtNewDescription";
            txtNewDescription.Size = new Size(100, 23);
            txtNewDescription.TabIndex = 10;
            // 
            // txtNewRating
            // 
            txtNewRating.Location = new Point(357, 242);
            txtNewRating.Name = "txtNewRating";
            txtNewRating.Size = new Size(100, 23);
            txtNewRating.TabIndex = 11;
            // 
            // txtNewDate
            // 
            txtNewDate.Location = new Point(357, 271);
            txtNewDate.Name = "txtNewDate";
            txtNewDate.Size = new Size(100, 23);
            txtNewDate.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(330, 194);
            label1.Name = "label1";
            label1.Size = new Size(21, 15);
            label1.TabIndex = 13;
            label1.Text = "ID:";
            // 
            // Description
            // 
            Description.AutoSize = true;
            Description.Location = new Point(281, 221);
            Description.Name = "Description";
            Description.Size = new Size(70, 15);
            Description.TabIndex = 14;
            Description.Text = "Description:";
            Description.Click += Description_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(307, 250);
            label3.Name = "label3";
            label3.Size = new Size(44, 15);
            label3.TabIndex = 15;
            label3.Text = "Rating:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(317, 279);
            label4.Name = "label4";
            label4.Size = new Size(34, 15);
            label4.TabIndex = 16;
            label4.Text = "Date:";
            // 
            // button5
            // 
            button5.Location = new Point(372, 301);
            button5.Margin = new Padding(3, 2, 3, 2);
            button5.Name = "button5";
            button5.Size = new Size(74, 26);
            button5.TabIndex = 17;
            button5.Text = "Update";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(372, 301);
            button6.Margin = new Padding(3, 2, 3, 2);
            button6.Name = "button6";
            button6.Size = new Size(74, 26);
            button6.TabIndex = 18;
            button6.Text = "Remove Reviews";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.Location = new Point(516, 295);
            label5.Name = "label5";
            label5.Size = new Size(172, 32);
            label5.TabIndex = 20;
            label5.Text = "Reviews Menu";
            // 
            // ReviewsMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(150, 120, 240);
            ClientSize = new Size(700, 338);
            Controls.Add(label5);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(Description);
            Controls.Add(label1);
            Controls.Add(txtNewDate);
            Controls.Add(txtNewRating);
            Controls.Add(txtNewDescription);
            Controls.Add(txtReviewId);
            Controls.Add(listBox1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "ReviewsMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ReviewsMenu";
            Load += ReviewsMenu_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private ListBox listBox1;
        private TextBox txtReviewId;
        private TextBox txtNewDescription;
        private TextBox txtNewRating;
        private TextBox txtNewDate;
        private Label label1;
        private Label Description;
        private Label label3;
        private Label label4;
        private Button button5;
        private Button button6;
        private Label label5;
    }
}