﻿using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WinFormsApp1
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            LogIn logIn = new LogIn();
            logIn.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string username = UsernameTxT.Text;
            string password = PasswordTxT.Text;
            string retype = RetypeTxT.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and password are required!");
                return;
            }

            if (password != retype)
            {
                MessageBox.Show("Passwords do not match!");
                return;
            }

            using (var db = new SteamDbContext())
            {
                var userExists = db.Users.Any(u => u.Username == username);
                if (userExists)
                {
                    MessageBox.Show("Username already taken!");
                    return;
                }

                var newUser = new Users
                {
                    Username = username,
                    Password = password, // ⚠️ по-хубаво е да се криптира, но за учебен проект е ок
                    Email = $"{username}@example.com", // ако искаш, може да сложиш textbox за email
                    Balance = 0
                };

                db.Users.Add(newUser);
                db.SaveChanges();
            }

            MessageBox.Show("Registration successful!");
            this.Hide(); // затваря Register формата
            LogIn logIn = new LogIn();
            logIn.Show();
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }
    }
}
