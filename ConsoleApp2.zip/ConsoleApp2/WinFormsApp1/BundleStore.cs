﻿using Microsoft.EntityFrameworkCore;
using Steam.Core;
using Steam.Data;
using Steam.Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class BundleStore : Form
    {
        private readonly SteamDbContext _context;
        private readonly Queries _queries;
        private readonly int _userId;

        public BundleStore(int userId)
        {
            InitializeComponent();
            _context = new SteamDbContext();
            _queries = new Queries(_context);
            _userId = userId;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonBuyBundle_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(textBoxBundleId.Text, out int bundleId))
                {
                    MessageBox.Show("Моля въведете валидно Bundle ID!");
                    return;
                }

                if (Session.CurrentUser == null)
                {
                    MessageBox.Show("Моля влезте в акаунта си, за да купите бъндъл.");
                    return;
                }

                using (var db = new SteamDbContext())
                {
                    var query = new Queries(db);
                    query.BuyBundle(Session.CurrentUser.UserId, bundleId);
                }

                MessageBox.Show("Бъндълът беше закупен успешно!");
                textBoxBundleId.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Грешка при покупка: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            using (var db = new SteamDbContext())
            {
                var bundles = db.Bundles
                    .Include(b => b.gamesBundles)
                    .ThenInclude(gb => gb.Game)
                    .ToList();

                foreach (var bundle in bundles)
                {
                    string gamesList = string.Join(", ", bundle.gamesBundles.Select(gb => gb.Game.Title));
                    listBox1.Items.Add($"ID: {bundle.BundleId}, Name: {bundle.Name}, Price: {bundle.Price}, Games: [{gamesList}]");
                }
            }
        }
    }
}
